<!-- including the head -->
<?php include('partials/head.php') ?>

    <title>Meya 372</title>
    <link rel="stylesheet" href="css/nav.css">
    <link rel="stylesheet" href="css/new_products.css">
</head>
<body>
    <div class="p_container">
        <?php include('partials/header.php') ?>
    
    </div>
</body>
</html>