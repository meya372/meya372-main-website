<!-- including the head -->
<?php include('partials/head.php') ?>

    <title>Meya 372</title>
    <link rel="stylesheet" href="css/nav.css">
    <link rel="stylesheet" href="css/products.css">
</head>
<body>
    <div class="p_container">
        <?php include('partials/header.php') ?>
       
       <div class="products">
            <h1 class="prods_title">Avaliable Used Laptops</h1>
            <div class="container">
                <div class="prod">
                    <img src="images/l1.png" alt="">
                    <p>Price: <span id="birr"> 18,000 Birr</span></p>
                    <p>Amet, molestiae hisse neque vero impedit alias?</p>
                    <a class="contact_us" href="product_detail.php">Buy now</a>
                </div>

                <div class="prod">
                    <img src="images/l2.png" alt="">
                    <p>Price: <span id="birr"> 18,000 Birr</span></p>
                    <p>Amet, molestiae hisse neque vero impedit alias?</p>
                    <a class="contact_us" href="product_detail.php">Buy now</a>
                </div>

                <div class="prod">
                    <img src="images/l3.png" alt="">
                    <p>Price: <span id="birr"> 18,000 Birr</span></p>
                    <p>Amet, molestiae hisse neque vero impedit alias?</p>
                    <a class="contact_us" href="product_detail.php">Buy now</a>
                </div>

                <div class="prod">
                    <img src="images/l4.png" alt="">
                    <p>Price: <span id="birr"> 18,000 Birr</span></p>
                    <p>Amet, molestiae hisse neque vero impedit alias?</p>
                    <a class="contact_us" href="product_detail.php">Buy now</a>
                </div>
                <div class="prod">
                    <img src="images/l1.png" alt="">
                    <p>Price: <span id="birr"> 18,000 Birr</span></p>
                    <p>Amet, molestiae hisse neque vero impedit alias?</p>
                    <a class="contact_us" href="product_detail.php">Buy now</a>
                </div>

                <div class="prod">
                    <img src="images/l2.png" alt="">
                    <p>Price: <span id="birr"> 18,000 Birr</span></p>
                    <p>Amet, molestiae hisse neque vero impedit alias?</p>
                    <a class="contact_us" href="product_detail.php">Buy now</a>
                </div>

                <div class="prod">
                    <img src="images/l3.png" alt="">
                    <p>Price: <span id="birr"> 18,000 Birr</span></p>
                    <p>Amet, molestiae hisse neque vero impedit alias?</p>
                    <a class="contact_us" href="product_detail.php">Buy now</a>
                </div>

                <div class="prod">
                    <img src="images/l4.png" alt="">
                    <p>Price: <span id="birr"> 18,000 Birr</span></p>
                    <p>Amet, molestiae hisse neque vero impedit alias?</p>
                    <a class="contact_us" href="product_detail.php">Buy now</a>
                </div>
                <div class="prod">
                    <img src="images/l1.png" alt="">
                    <p>Price: <span id="birr"> 18,000 Birr</span></p>
                    <p>Amet, molestiae hisse neque vero impedit alias?</p>
                    <a class="contact_us" href="product_detail.php">Buy now</a>
                </div>

                <div class="prod">
                    <img src="images/l2.png" alt="">
                    <p>Price: <span id="birr"> 18,000 Birr</span></p>
                    <p>Amet, molestiae hisse neque vero impedit alias?</p>
                    <a class="contact_us" href="product_detail.php">Buy now</a>
                </div>

                <div class="prod">
                    <img src="images/l3.png" alt="">
                    <p>Price: <span id="birr"> 18,000 Birr</span></p>
                    <p>Amet, molestiae hisse neque vero impedit alias?</p>
                    <a class="contact_us" href="product_detail.php">Buy now</a>
                </div>

                <div class="prod">
                    <img src="images/l4.png" alt="">
                    <p>Price: <span id="birr"> 18,000 Birr</span></p>
                    <p>Amet, molestiae hisse neque vero impedit alias?</p>
                    <a class="contact_us" href="product_detail.php">Buy now</a>
                </div>
            </div>
       </div>
    </div>

    <script src="script.js">
    </script>
</body>
</html>