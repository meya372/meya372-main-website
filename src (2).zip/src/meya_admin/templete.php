<!-- including the head -->
<?php include 'admin_partials/head.php'?>

    <title>Meya ADMIN</title>
    <link rel="stylesheet" href="admin_css/style.css">
</head>

<!-- including the header -->
<?php include 'admin_partials/header.php'?>


<!-- including the footer -->
<?php include 'admin_partials/footer.php'?>
                