                <footer>
                    <p> &#169; 2022 Copyright. All rights reserved. Meya372
                    <a id="to_top" href="#top"><i class="fa-solid fa-angle-up"></i></a>    
                    </p>
                    
                </footer>

            </div>

        </div>
    </div>

    
    <script src="admin_partials/index.js"></script>
</body>
</html>