

        <footer id="footer">
            <div class="footer_1">
                <div class="container">
                    <div class="footer_about">                    
                        <h1>Meya 372</h1>
                        <p>Lorem ipsum dolor, sit minima vero quae blandit molestiae suscipit laboriosam ex voluptate?</p>
                    </div>

                    <div class="footer_contact">
                        <p>
                            <i class="fa-solid fa-location-dot"></i>
                            Dir-Tera, Addis Ababa, Ethiopia
                        </p>
        
                        <p>
                            <a style="color:white" href="tel:0993820873"><i class="fa-solid fa-phone"></i>09 93 82 08 73</a>
                            
                        </p>
        
                        <p>
                            <i class="fa-solid fa-envelope"></i>
                            <a href="#">meya372@gmail.com</a>
                        </p>
                    </div>

                    <div class="map">
                        <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3940.324438515835!2d38.733975099999995!3d9.0341398!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x164b860120e9b9bb%3A0xd44281cd3572e55d!2zS2VyZW1lbGEgQnVpbGRpbmcgfCBNZXJrYXRvIHwg4Yqo4Yio4Yic4YiLIOGIheGKleGMuyB8IOGImOGIreGKq-GJtg!5e0!3m2!1sen!2set!4v1665816484444!5m2!1sen!2set" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
                    </div>
                    
                </div>

            </div>
            

            <div class="footer_2">
                <div class="container">
                    <p> &#169;<?php echo date("Y")?> Copyright. All rights reserved. Meya372 </p>
                </div>
            </div>
        </footer>
</body>
</html>